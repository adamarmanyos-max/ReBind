# ReBind

A standalone Fabric client mod for Minecraft 1.16.1 that adds an in-game key
rebinding screen. No Fabric API dependency.

- Press **K** (default) to open the ReBind screen.
- Click a binding, then press any key or mouse button to assign it.
- **Escape** clears a binding instead of closing the screen.
- Conflicts with other bindings are highlighted in red.

Bindings are injected into `GameOptions.keysAll`, so they persist in
`options.txt` and also appear in the vanilla Controls screen.

## Building

```
./gradlew build
```

Requires JDK 17 to run Gradle/Loom. The jar is compiled to Java 8 bytecode,
so it loads on any JVM from 8 upward.

## MCSR note

This mod is not on the approved mod list. It is fine for practice, but runs
recorded with it will not pass verification unless it goes through the MCSR
mod approval process.
