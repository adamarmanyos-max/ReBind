package com.example.toolkeys;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.options.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class KeybindScreen extends Screen {

    private final Screen parent;
    private final List<ButtonWidget> bindButtons = new ArrayList<>();

    /** The binding currently waiting for a key press, or null. */
    private KeyBinding selected;

    public KeybindScreen(Screen parent) {
        super(new LiteralText("Tool Keys"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        bindButtons.clear();

        int y = 40;
        for (KeyBinding binding : ToolKeys.KEYS) {
            final KeyBinding target = binding;

            // Label on the left, button on the right.
            ButtonWidget button = new ButtonWidget(
                    this.width / 2 + 5, y, 110, 20,
                    labelFor(target),
                    b -> {
                        this.selected = target;
                        refreshLabels();
                    });

            this.addButton(button);
            bindButtons.add(button);
            y += 24;
        }

        this.addButton(new ButtonWidget(
                this.width / 2 - 75, Math.min(y + 12, this.height - 30), 150, 20,
                new TranslatableText("gui.done"),
                b -> this.onClose()));
    }

    private Text labelFor(KeyBinding binding) {
        Text bound = binding.getBoundKeyLocalizedText();
        if (binding == selected) {
            return new LiteralText("> ")
                    .append(bound.shallowCopy().formatted(Formatting.YELLOW))
                    .append(" <")
                    .formatted(Formatting.YELLOW);
        }
        if (isConflicting(binding)) {
            return bound.shallowCopy().formatted(Formatting.RED);
        }
        return bound;
    }

    /** True if any other registered binding (vanilla included) uses the same key. */
    private boolean isConflicting(KeyBinding binding) {
        if (binding.isUnbound() || this.client == null) return false;
        for (KeyBinding other : this.client.options.keysAll) {
            if (other != binding && binding.equals(other)) return true;
        }
        return false;
    }

    private void refreshLabels() {
        for (int i = 0; i < bindButtons.size(); i++) {
            bindButtons.get(i).setMessage(labelFor(ToolKeys.KEYS.get(i)));
        }
    }

    private void bind(InputUtil.Key key) {
        if (this.client == null || selected == null) return;
        this.client.options.setKeyCode(selected, key);
        KeyBinding.updateKeysByCode();
        this.client.options.write();   // persists into options.txt
        selected = null;
        refreshLabels();
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (selected != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                bind(InputUtil.UNKNOWN_KEY);        // Escape clears the binding
            } else {
                bind(InputUtil.fromKeyCode(keyCode, scanCode));
            }
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (selected != null) {
            bind(InputUtil.Type.MOUSE.createFromCode(button));
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        this.renderBackground(matrices);
        drawCenteredText(matrices, this.textRenderer, this.title,
                this.width / 2, 15, 0xFFFFFF);

        int y = 40;
        for (KeyBinding binding : ToolKeys.KEYS) {
            this.textRenderer.draw(matrices,
                    new TranslatableText(binding.getTranslationKey()),
                    this.width / 2f - 115, y + 6, 0xFFFFFF);
            y += 24;
        }

        super.render(matrices, mouseX, mouseY, delta);
    }

    @Override
    public void onClose() {
        if (this.client != null) this.client.openScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;   // don't pause a singleplayer world
    }
}
