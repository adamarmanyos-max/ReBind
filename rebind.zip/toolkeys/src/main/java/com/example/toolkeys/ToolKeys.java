package com.example.toolkeys;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.options.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ToolKeys implements ClientModInitializer {

    /**
     * Use an existing vanilla category. A custom category string requires also
     * inserting it into KeyBinding's CATEGORY_ORDER_MAP via an accessor mixin,
     * otherwise the vanilla Controls screen throws while sorting.
     */
    private static final String CATEGORY = "key.categories.misc";

    /** Every binding this mod owns, in the order they show up on the screen. */
    public static final List<KeyBinding> KEYS = new ArrayList<>();

    public static final KeyBinding OPEN_SCREEN = register(
            "key.toolkeys.open_screen", GLFW.GLFW_KEY_K);

    public static final KeyBinding SLOT_PICK = register(
            "key.toolkeys.slot_pick", GLFW.GLFW_KEY_UNKNOWN);

    private static KeyBinding register(String translationKey, int defaultKey) {
        KeyBinding binding = new KeyBinding(
                translationKey,
                InputUtil.Type.KEYSYM,
                defaultKey,
                CATEGORY);
        KEYS.add(binding);
        return binding;
    }

    @Override
    public void onInitializeClient() {
        // Nothing to do here. The bindings are created by the static
        // initializer above and injected into GameOptions by GameOptionsMixin.
    }

    /** Example action fired by SLOT_PICK. Replace with whatever you need. */
    public static void onSlotPick(MinecraftClient client) {
        if (client.player == null) return;
        int slot = client.player.inventory.selectedSlot;
        client.player.inventory.selectedSlot = (slot + 1) % 9;
    }
}
