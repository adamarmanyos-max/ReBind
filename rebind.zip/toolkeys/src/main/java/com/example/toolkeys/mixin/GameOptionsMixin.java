package com.example.toolkeys.mixin;

import com.example.toolkeys.ToolKeys;
import net.minecraft.client.options.GameOptions;
import net.minecraft.client.options.KeyBinding;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Without Fabric API's KeyBindingHelper we register bindings ourselves:
 * KeyBinding's constructor already puts the instance into its static
 * KEYS_BY_ID map, but the game only ticks, saves and displays bindings that
 * live in GameOptions.keysAll. Appending here happens before options.txt is
 * read, so saved bindings load normally.
 */
@Mixin(GameOptions.class)
public class GameOptionsMixin {

    @Shadow
    public KeyBinding[] keysAll;

    @Inject(method = "<init>", at = @At("RETURN"))
    private void toolkeys$addKeyBindings(CallbackInfo ci) {
        List<KeyBinding> all = new ArrayList<>(Arrays.asList(this.keysAll));
        all.addAll(ToolKeys.KEYS);
        this.keysAll = all.toArray(new KeyBinding[0]);
    }
}
