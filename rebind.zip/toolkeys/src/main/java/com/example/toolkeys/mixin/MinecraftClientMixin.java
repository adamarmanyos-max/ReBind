package com.example.toolkeys.mixin;

import com.example.toolkeys.KeybindScreen;
import com.example.toolkeys.ToolKeys;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * handleInputEvents runs once per client tick while no screen is open, which
 * is exactly where vanilla drains its own wasPressed() queues.
 */
@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {

    @Inject(method = "handleInputEvents", at = @At("RETURN"))
    private void toolkeys$handleInputEvents(CallbackInfo ci) {
        MinecraftClient client = (MinecraftClient) (Object) this;

        while (ToolKeys.OPEN_SCREEN.wasPressed()) {
            client.openScreen(new KeybindScreen(client.currentScreen));
        }
        while (ToolKeys.SLOT_PICK.wasPressed()) {
            ToolKeys.onSlotPick(client);
        }
    }
}
